# Face Mask Detection > 2024-07-20 8:07am
https://universe.roboflow.com/object-detection-project-q3aru/face-mask-detection-vudgm

Provided by a Roboflow user
License: CC BY 4.0

